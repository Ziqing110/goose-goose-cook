import React, { useState } from 'react';
import './MatureChefGoose.css';

const ICONS = {
  listen: <><path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Z"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3M8 22h8"/></>,
  voice: <><path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15 9.5a4 4 0 0 1 0 5M18 7a8 8 0 0 1 0 10"/></>,
  subtitle: <><rect x="2" y="5" width="20" height="14" rx="3"/><path d="M10 10a2 2 0 1 0 0 4M18 10a2 2 0 1 0 0 4"/></>,
};
function Icon({name}) { return <svg viewBox="0 0 24 24" aria-hidden="true">{ICONS[name]}</svg>; }

export default function MatureChefGoose({
  state='idle', assetBase='/assets/mature-chef-goose',
  listening=true, voice=true, subtitles=true,
  onListeningChange, onVoiceChange, onSubtitlesChange,
  label='Chef Goose voice assistant', className=''
}) {
  const [engaged,setEngaged]=useState(false);
  const [touchPinned,setTouchPinned]=useState(false);
  const pose=engaged?'hover':state;
  const source=`${assetBase}/mature-goose-${pose}.webp`;
  const controls=[
    ['listen',listening,onListeningChange,listening?'Mute listening':'Start listening'],
    ['voice',voice,onVoiceChange,voice?'Mute goose voice':'Turn goose voice on'],
    ['subtitle',subtitles,onSubtitlesChange,subtitles?'Hide subtitles':'Show subtitles'],
  ];
  const leave=()=>{ if(!touchPinned) setEngaged(false); };
  const toggleTouch=(event)=>{
    if(event.pointerType==='touch' || window.matchMedia('(hover:none)').matches){
      const next=!touchPinned;
      setTouchPinned(next);
      setEngaged(next);
    }
  };
  return <section className={`mcg-agent ${engaged?'is-engaged':''} ${className}`} aria-label={label} onMouseLeave={leave} onBlur={(event)=>{if(!event.currentTarget.contains(event.relatedTarget)) leave();}}>
    <button className="mcg-goose" type="button" onMouseEnter={()=>setEngaged(true)} onFocus={()=>setEngaged(true)} onClick={toggleTouch} aria-expanded={engaged}>
      <img src={source} alt="" />
    </button>
    <div className="mcg-eggs" aria-label="Quick voice controls">
      {controls.map(([name,on,change,aria])=><button key={name} className={`mcg-egg mcg-${name} ${on?'is-on':'is-off'}`} type="button" aria-label={aria} aria-pressed={on} onClick={()=>change?.(!on)}><Icon name={name}/></button>)}
    </div>
  </section>;
}
