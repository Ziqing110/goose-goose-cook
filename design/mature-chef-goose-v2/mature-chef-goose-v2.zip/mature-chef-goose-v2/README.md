# Mature Chef Goose v2

Six-state adult Chef Goose voice-agent package. The character uses a rounded elongated head, natural broad beak, long curved neck, white chef toque, and light warm cream full bib apron with burnt-orange straps and waist tie. It has no neck scarf.

## States

- `idle`
- `listening`
- `thinking`
- `speaking`
- `warning`
- `hover` — UI-only greeting state used while the controls are revealed

## Assets

- `png/` — transparent static PNG, 1254 × 1254
- `animated/webp/` — transparent looping WebP, 320 × 320
- `animated/sprites/` — horizontal transparent PNG sprite sheets
- `animated/posters/` — first-frame PNG, 320 × 320
- `animated/manifest.json` — frame count, timing, dimensions, and paths
- `preview.html` — all six animation states

## Floating UI

Serve `ui/index.html` from any static web server. The three egg controls stay hidden. Pointer hover, keyboard focus, or touch on the goose switches it to the dedicated `hover` animation and makes the controls pop up in sequence below the character. The eggs independently control listening, goose voice, and subtitles. Moving away restores the current runtime state.

The UI is independent of a model or audio backend. Integration code should call the appropriate state asset and connect the three button events to the product voice session.

`components/MatureChefGoose.jsx` and `MatureChefGoose.css` provide the same interaction as a reusable React component. Set `assetBase` to the deployed WebP asset folder.
