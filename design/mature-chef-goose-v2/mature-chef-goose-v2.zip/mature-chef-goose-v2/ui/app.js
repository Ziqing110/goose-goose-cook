const ASSET = (state) => `assets/mature-goose-${state}.webp`;
const COPY = {
  idle: 'Ready when you are.',
  listening: 'I’m listening — tell me what you need.',
  thinking: 'Let me think through the next step.',
  speaking: 'Add the stock slowly and keep stirring.',
  warning: 'The pan is getting hot — turn the heat down.'
};
const ALT = {
  idle: 'Mature Chef Goose waiting calmly',
  listening: 'Mature Chef Goose listening with one wing by its head',
  thinking: 'Mature Chef Goose thinking with one wing under its beak',
  speaking: 'Mature Chef Goose speaking proudly',
  warning: 'Mature Chef Goose calling out a warning',
  hover: 'Mature Chef Goose waving hello'
};

const shell = document.querySelector('#agent-shell');
const gooseHit = document.querySelector('#goose-hit');
const gooseImage = document.querySelector('#goose-image');
const eggControls = document.querySelector('#egg-controls');
const stateTitle = document.querySelector('#state-title');
const subtitleBar = document.querySelector('#subtitle-bar');
const subtitleCopy = document.querySelector('#subtitle-copy');
const subtitleAvatar = document.querySelector('.subtitle-avatar img');
const listenButton = document.querySelector('#listen-button');
const voiceButton = document.querySelector('#voice-button');
const subtitleButton = document.querySelector('#subtitle-button');

let baseState = 'idle';
let listening = true;
let voice = true;
let subtitles = true;
let touchPinned = false;
let leaveTimer = null;

function setImage(state) {
  gooseImage.src = ASSET(state);
  gooseImage.alt = ALT[state];
}
function setState(state) {
  baseState = state;
  if (!shell.classList.contains('is-engaged')) setImage(state);
  stateTitle.textContent = state[0].toUpperCase() + state.slice(1);
  subtitleCopy.textContent = COPY[state] || COPY.idle;
  subtitleAvatar.src = ASSET(state);
  document.querySelectorAll('.state-picker button').forEach(button => button.classList.toggle('active', button.dataset.state === state));
}
function engage() {
  if (leaveTimer) {
    clearTimeout(leaveTimer);
    leaveTimer = null;
  }
  shell.classList.add('is-engaged');
  gooseHit.setAttribute('aria-expanded','true');
  setImage('hover');
}
function disengage() {
  if (leaveTimer) {
    clearTimeout(leaveTimer);
    leaveTimer = null;
  }
  if (touchPinned) return;
  shell.classList.remove('is-engaged');
  gooseHit.setAttribute('aria-expanded','false');
  setImage(baseState);
}
function scheduleDisengage() {
  if (touchPinned) return;
  if (leaveTimer) clearTimeout(leaveTimer);
  leaveTimer = setTimeout(disengage, 1800);
}
function toggleButton(button, on, onLabel, offLabel) {
  button.classList.toggle('is-on', on);
  button.classList.toggle('is-off', !on);
  button.setAttribute('aria-pressed', String(on));
  button.setAttribute('aria-label', on ? onLabel : offLabel);
}

gooseHit.addEventListener('pointerenter', engage);
shell.addEventListener('pointerenter', engage);
shell.addEventListener('pointerleave', scheduleDisengage);
eggControls.addEventListener('pointerenter', engage);
gooseHit.addEventListener('focus', engage);
shell.addEventListener('focusout', event => { if (!shell.contains(event.relatedTarget)) scheduleDisengage(); });
gooseHit.addEventListener('click', event => {
  if (event.pointerType === 'touch' || matchMedia('(hover:none)').matches) {
    touchPinned = !touchPinned;
    if (touchPinned) {
      engage();
    } else {
      shell.classList.remove('is-engaged');
      gooseHit.setAttribute('aria-expanded','false');
      setImage(baseState);
    }
  }
});

document.querySelectorAll('.state-picker button').forEach(button => button.addEventListener('click', () => setState(button.dataset.state)));
listenButton.addEventListener('click', () => {
  listening = !listening;
  toggleButton(listenButton, listening, 'Mute listening', 'Start listening');
  if (!listening && baseState === 'listening') setState('idle');
});
voiceButton.addEventListener('click', () => {
  voice = !voice;
  toggleButton(voiceButton, voice, 'Mute goose voice', 'Turn goose voice on');
});
subtitleButton.addEventListener('click', () => {
  subtitles = !subtitles;
  toggleButton(subtitleButton, subtitles, 'Hide subtitles', 'Show subtitles');
  subtitleBar.classList.toggle('is-visible', subtitles);
});
